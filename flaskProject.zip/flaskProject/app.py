from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)


@app.route("/")
def home():
    return render_template('MyCVHomePage.html')


@app.route("/8")
def assignment8():
    return render_template('Assigment8.html',
                           user={'firstname': "Ziv", 'lastname': "Bach"},
                           Hobbies=['Be With Friends', 'Shopping', 'Go To the Beach', 'Hear Music', 'Eat good Food'])


@app.route("/userlist")
def userlist():
    return render_template('USERLIST.html')


@app.route("/stayintouch")
def stayintouch():
    return render_template('Stay In touch.html')


@app.route("/recommendation")
def recommendation():
    return render_template('Recommendation.html')


# run the application
if __name__ == "__main__":
    app.run(debug=True)
